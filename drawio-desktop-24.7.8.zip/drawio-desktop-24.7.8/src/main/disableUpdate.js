export function disableUpdate()
{
	return false;
}